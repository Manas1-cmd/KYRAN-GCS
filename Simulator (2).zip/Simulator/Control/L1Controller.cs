﻿using System;

namespace SimpleDroneGCS.Simulator.Control
{
    /// <summary>
    /// Порт ArduPilot L1 Guidance Controller (Park, Deyst, How 2004).
    /// Стандартный алгоритм навигации UAV. Используется в ArduPilot, PX4 и других.
    /// 
    /// Принцип:
    /// - L1 расстояние = look-ahead distance (сколько вперёд "смотрит" контроллер)
    /// - Берётся точка на желаемой траектории на расстоянии L1
    /// - η = угол между текущей скоростью и направлением на L1-точку
    /// - Lateral acceleration = K · V² / L1 · sin(η)
    /// - Это даёт плавный заход на линию и плавные повороты на дугу
    /// 
    /// Источник: https://github.com/ArduPilot/ardupilot/blob/master/libraries/AP_L1_Control/AP_L1_Control.cpp
    /// </summary>
    public sealed class L1Controller
    {
        // Параметры (значения по умолчанию из ArduPilot)
        public double L1_period = 17.0;     // период tracking loop, сек
        public double L1_damping = 0.75;    // демпфирование (0.6...1.0)
        public const double GRAVITY = 9.80665;

        // Состояние
        private double _L1_dist;            // динамическая look-ahead distance
        private double _latAccDem;          // последнее ускорение (м/с²)
        private double _crosstrackError;    // отклонение от линии
        private double _navBearingRad;      // bearing от ВС к L1 точке
        private double _lastNu;             // последний угол ошибки (для prevent_indecision)
        private bool _wpCircle;             // в режиме "облёт"

        // Outputs
        public double LateralAccelerationDemand => _latAccDem;
        public double CrossTrackError => _crosstrackError;
        public double NavBearingRad => _navBearingRad;
        public double L1Distance => _L1_dist;
        public bool ReachedLoiterTarget => _wpCircle;

        // =====================================================================
        // Геометрия — local NE координаты (метры) от current position
        // =====================================================================

        /// <summary>
        /// Вектор NE от точки A к точке B в метрах (локальная плоская проекция).
        /// </summary>
        private static (double n, double e) GetDistanceNE(
            double latA, double lonA, double latB, double lonB)
        {
            double n = (latB - latA) * Navigator.MetersPerDegLat;
            double cosLat = Math.Cos(latA * Navigator.DegToRad);
            double e = (lonB - lonA) * Navigator.MetersPerDegLat * cosLat;
            return (n, e);
        }

        // =====================================================================
        // L1 для движения по waypoint (между prev_WP и next_WP)
        // =====================================================================

        /// <summary>
        /// Обновляет L1 контроллер для линейного полёта prev_WP → next_WP.
        /// </summary>
        /// <param name="curLat">текущая широта</param>
        /// <param name="curLon">текущая долгота</param>
        /// <param name="prevLat">предыдущая WP широта</param>
        /// <param name="prevLon">предыдущая WP долгота</param>
        /// <param name="nextLat">следующая WP широта</param>
        /// <param name="nextLon">следующая WP долгота</param>
        /// <param name="vN">скорость на север, м/с</param>
        /// <param name="vE">скорость на восток, м/с</param>
        /// <param name="yawRad">текущий курс ВС, радианы</param>
        /// <param name="dt">шаг, сек</param>
        public void UpdateWaypoint(
            double curLat, double curLon,
            double prevLat, double prevLon,
            double nextLat, double nextLon,
            double vN, double vE, double yawRad,
            double dt)
        {
            // Coefficient K_L1 = 4 * damping²
            double K_L1 = 4.0 * L1_damping * L1_damping;

            // Скорость
            double groundSpeed = Math.Sqrt(vN * vN + vE * vE);
            if (groundSpeed < 0.1)
            {
                groundSpeed = 0.1;
                vN = Math.Cos(yawRad) * groundSpeed;
                vE = Math.Sin(yawRad) * groundSpeed;
            }

            // Динамическая L1 distance: L1 = (1/π) · damping · period · groundSpeed
            _L1_dist = Math.Max(0.3183099 * L1_damping * L1_period * groundSpeed, 1.0);

            // AB вектор: prev_WP → next_WP
            var (abN, abE) = GetDistanceNE(prevLat, prevLon, nextLat, nextLon);
            double AB_length = Math.Sqrt(abN * abN + abE * abE);

            if (AB_length < 1e-6)
            {
                // Точки совпадают — лети напрямую
                var (toNextN, toNextE) = GetDistanceNE(curLat, curLon, nextLat, nextLon);
                AB_length = Math.Sqrt(toNextN * toNextN + toNextE * toNextE);
                if (AB_length < 1e-6)
                {
                    abN = Math.Cos(yawRad);
                    abE = Math.Sin(yawRad);
                    AB_length = 1.0;
                }
                else
                {
                    abN = toNextN;
                    abE = toNextE;
                }
            }
            // Нормализуем AB
            abN /= AB_length;
            abE /= AB_length;

            // A_air: вектор от prev_WP до ВС
            var (aAirN, aAirE) = GetDistanceNE(prevLat, prevLon, curLat, curLon);

            // Cross-track error (расстояние от ВС до линии AB)
            // 2D cross product: A_air × AB
            _crosstrackError = aAirN * abE - aAirE * abN;

            // Along-track distance (как далеко прошёл вдоль линии)
            double alongTrackDist = aAirN * abN + aAirE * abE;

            double WP_A_dist = Math.Sqrt(aAirN * aAirN + aAirE * aAirE);

            double Nu;

            // Если ВС позади WP A более чем на 135° и далеко — летим к A
            if (WP_A_dist > _L1_dist
                && alongTrackDist / Math.Max(WP_A_dist, 1.0) < -0.7071)
            {
                // Лети к WP A
                double aAirUnitN = aAirN / WP_A_dist;
                double aAirUnitE = aAirE / WP_A_dist;
                // xtrackVel = velocity × (-A_unit)  (cross product 2D)
                double xtrackVel = vN * (-aAirUnitE) - vE * (-aAirUnitN);
                double ltrackVel = vN * (-aAirUnitN) + vE * (-aAirUnitE);
                Nu = Math.Atan2(xtrackVel, ltrackVel);
                _navBearingRad = Math.Atan2(-aAirUnitE, -aAirUnitN);
            }
            else if (alongTrackDist > AB_length + groundSpeed * 3.0)
            {
                // Прошли B на 3 секунды — возвращаемся к B
                var (bAirN, bAirE) = GetDistanceNE(nextLat, nextLon, curLat, curLon);
                double bDist = Math.Sqrt(bAirN * bAirN + bAirE * bAirE);
                if (bDist < 1e-6) bDist = 1e-6;
                double bAirUnitN = bAirN / bDist;
                double bAirUnitE = bAirE / bDist;
                double xtrackVel = vN * (-bAirUnitE) - vE * (-bAirUnitN);
                double ltrackVel = vN * (-bAirUnitN) + vE * (-bAirUnitE);
                Nu = Math.Atan2(xtrackVel, ltrackVel);
                _navBearingRad = Math.Atan2(-bAirUnitE, -bAirUnitN);
            }
            else
            {
                // Нормальный случай: летим вдоль AB
                // Nu2: угол скорости относительно линии AB
                double xtrackVel = vN * abE - vE * abN;
                double ltrackVel = vN * abN + vE * abE;
                double Nu2 = Math.Atan2(xtrackVel, ltrackVel);

                // Nu1: угол к L1 reference точке
                double sineNu1 = _crosstrackError / Math.Max(_L1_dist, 0.1);
                // Limit для capture angle 45°
                sineNu1 = Math.Clamp(sineNu1, -0.7071, 0.7071);
                double Nu1 = Math.Asin(sineNu1);

                Nu = Nu1 + Nu2;
                // bearing к L1 точке = направление AB + Nu1
                double abBearing = Math.Atan2(abE, abN);
                _navBearingRad = WrapPi(abBearing + Nu1);
            }

            PreventIndecision(ref Nu);
            _lastNu = Nu;

            // Limit Nu к +- π/2
            Nu = Math.Clamp(Nu, -Math.PI / 2, Math.PI / 2);

            // Lateral acceleration demand: a = K · V²/L1 · sin(Nu)
            _latAccDem = K_L1 * groundSpeed * groundSpeed / _L1_dist * Math.Sin(Nu);

            _wpCircle = false;
        }

        // =====================================================================
        // L1 для loiter (облёт точки на радиусе)
        // =====================================================================

        /// <summary>
        /// Обновляет L1 для облёта точки center_WP с радиусом radius.
        /// </summary>
        /// <param name="loiterDirection">+1 = по часовой, -1 = против</param>
        public void UpdateLoiter(
            double curLat, double curLon,
            double centerLat, double centerLon,
            double radius, int loiterDirection,
            double vN, double vE, double yawRad,
            double dt)
        {
            // PD control gains for circle tracking
            double omega = (2.0 * Math.PI / L1_period);
            double Kx = omega * omega;
            double Kv = 2.0 * L1_damping * omega;
            double K_L1 = 4.0 * L1_damping * L1_damping;

            double groundSpeed = Math.Max(Math.Sqrt(vN * vN + vE * vE), 1.0);

            // Динамическая L1 distance
            _L1_dist = 0.3183099 * L1_damping * L1_period * groundSpeed;

            // A_air: от центра до ВС
            var (aAirN, aAirE) = GetDistanceNE(centerLat, centerLon, curLat, curLon);
            double aAirLen = Math.Sqrt(aAirN * aAirN + aAirE * aAirE);

            double aUnitN, aUnitE;
            if (aAirLen > 0.1)
            {
                aUnitN = aAirN / aAirLen;
                aUnitE = aAirE / aAirLen;
            }
            else if (groundSpeed > 0.1)
            {
                aUnitN = vN / groundSpeed;
                aUnitE = vE / groundSpeed;
            }
            else
            {
                aUnitN = Math.Cos(yawRad);
                aUnitE = Math.Sin(yawRad);
            }

            // Capture mode (когда ВС вне круга)
            // xtrackVelCap = A_unit × velocity (cross 2D)
            double xtrackVelCap = aUnitN * vE - aUnitE * vN;
            // ltrackVelCap = -(velocity · A_unit) — radial inbound
            double ltrackVelCap = -(vN * aUnitN + vE * aUnitE);
            double Nu = Math.Atan2(xtrackVelCap, ltrackVelCap);
            PreventIndecision(ref Nu);
            _lastNu = Nu;
            Nu = Math.Clamp(Nu, -Math.PI / 2, Math.PI / 2);

            double latAccDemCap = K_L1 * groundSpeed * groundSpeed / _L1_dist * Math.Sin(Nu);

            // Circle mode (когда ВС на круге)
            double xtrackVelCirc = -ltrackVelCap;       // radial outbound
            double xtrackErrCirc = aAirLen - radius;    // отклонение от радиуса
            _crosstrackError = xtrackErrCirc;

            double latAccDemCircPD = xtrackErrCirc * Kx + xtrackVelCirc * Kv;

            // Tangential velocity
            double velTangent = xtrackVelCap * loiterDirection;

            // Защита от поворота не туда
            if (ltrackVelCap < 0.0 && velTangent < 0.0)
            {
                latAccDemCircPD = Math.Max(latAccDemCircPD, 0.0);
            }

            // Centripetal acceleration
            double radiusSafe = Math.Max(0.5 * radius, radius + xtrackErrCirc);
            double latAccDemCircCtr = velTangent * velTangent / radiusSafe;

            double latAccDemCirc = loiterDirection * (latAccDemCircPD + latAccDemCircCtr);

            // Switchover между capture и circle
            if (xtrackErrCirc > 0.0
                && loiterDirection * latAccDemCap < loiterDirection * latAccDemCirc)
            {
                _latAccDem = latAccDemCap;
                _wpCircle = false;
                _navBearingRad = Math.Atan2(-aUnitE, -aUnitN);
            }
            else
            {
                _latAccDem = latAccDemCirc;
                _wpCircle = true;
                _navBearingRad = Math.Atan2(-aUnitE, -aUnitN);
            }
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        public void Reset()
        {
            _L1_dist = 0;
            _latAccDem = 0;
            _crosstrackError = 0;
            _navBearingRad = 0;
            _lastNu = 0;
            _wpCircle = false;
        }

        /// <summary>
        /// Защита от осцилляций при остром угле.
        /// </summary>
        private void PreventIndecision(ref double Nu)
        {
            const double NuLimit = 0.9 * Math.PI;
            if (Math.Abs(Nu) > NuLimit
                && Math.Abs(_lastNu) > NuLimit
                && Nu * _lastNu < 0.0)
            {
                Nu = _lastNu;
            }
        }

        private static double WrapPi(double a)
        {
            while (a > Math.PI) a -= 2 * Math.PI;
            while (a < -Math.PI) a += 2 * Math.PI;
            return a;
        }
    }
}