using SimpleDroneGCS.Controls;
using SimpleDroneGCS.Services;
using SimpleDroneGCS.UI.Dialogs;
using SimpleDroneGCS.Views;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Management;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

using static SimpleDroneGCS.Helpers.Loc;

namespace SimpleDroneGCS
{
    public partial class MainWindow : Window
    {
        private bool _isConnected = false;
        private Button _activeNavButton = null;

        private FlightPlanView _flightPlanView;

        private CameraWindow _cameraWindow;

        public MAVLinkService MAVLink { get; private set; }

        public MainWindow()
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private void InitializeMAVLink()
        {
            MAVLink = new MAVLinkService();
            MAVLink.ConnectionStatusChanged_Bool += OnConnectionStatusChanged;
            MAVLink.TelemetryReceived += OnTelemetryReceived;
        }

        private void OnConnectionStatusChanged(object sender, bool isConnected)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private void OnTelemetryReceived(object sender, EventArgs e)
        {

        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void ConnectToDrone()
        {
            // ... реализация (23 строк) ...
            throw new NotImplementedException();
        }

        private void DisconnectFromDrone()
        {
            MAVLink.Disconnect();
        }

        private void UpdateConnectionUI()
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private void NavigationButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
                NavigateToPage(button);
        }

        private void NavigateToPage(Button button)
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }

        private void CameraButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void LandButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (15 строк) ...
            throw new NotImplementedException();
        }

        private void RthButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (15 строк) ...
            throw new NotImplementedException();
        }

        protected override void OnClosed(EventArgs e)
        {

            MAVLink?.Disconnect();
            base.OnClosed(e);
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = this.WindowState == WindowState.Maximized
                ? WindowState.Normal
                : WindowState.Maximized;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
