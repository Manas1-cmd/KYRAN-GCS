using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using static SimpleDroneGCS.Helpers.Loc;

namespace SimpleDroneGCS.UI.Dialogs
{
    public class WaypointEditDialog : Window
    {
        
        public double Latitude { get; private set; }
        public double Longitude { get; private set; }
        public double Altitude { get; private set; }
        public double Radius { get; private set; }
        public double Delay { get; private set; }
        public int LoiterTurns { get; private set; }
        public bool AutoNext { get; private set; }
        public bool Clockwise { get; private set; }
        public string CommandType { get; private set; }  

        private TextBox _latBox, _lngBox, _altBox, _radBox, _delayBox, _turnsBox;
        private CheckBox _autoNextBox;
        private Border _cwButton, _ccwButton;
        private ComboBox _commandCombo;  
        private bool _isClockwise;
        private bool _isVtol;  

        public WaypointEditDialog(int waypointNumber, double lat, double lng, double alt,
                                  double radius, double delay, int turns, bool autoNext, bool clockwise,
                                  string commandType = "WAYPOINT", bool isVtol = false)  
        {
            // ... реализация (24 строк) ...
            throw new NotImplementedException();
        }

        private void BuildUI(int wpNum)
        {
            // ... реализация (233 строк) ...
            throw new NotImplementedException();
        }

        private Border CreateDirectionButton(string text, bool isCw)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void SetDirection(bool clockwise)
        {
            _isClockwise = clockwise;
            UpdateDirectionButtons();
        }

        private void UpdateDirectionButtons()
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        private StackPanel CreateInputRow(string label, string value, TextBox textBox)
        {
            // ... реализация (31 строк) ...
            throw new NotImplementedException();
        }

        private Style CreateCheckBoxStyle()
        {
            // ... реализация (34 строк) ...
            throw new NotImplementedException();
        }

        private void SaveButton_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (37 строк) ...
            throw new NotImplementedException();
        }
    }
}