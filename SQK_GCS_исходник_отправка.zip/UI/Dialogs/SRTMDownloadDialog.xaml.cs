using SimpleDroneGCS.Services;
using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SimpleDroneGCS.UI.Dialogs
{
    public partial class SRTMDownloadDialog : Window
    {
        private CancellationTokenSource _cts;
        private double _currentLat;
        private double _currentLon;

        private readonly (double minLat, double maxLat, double minLon, double maxLon) _kzBounds = (40, 56, 46, 88);
        private readonly (double minLat, double maxLat, double minLon, double maxLon) _almatyBounds = (43, 44, 76, 78);
        private readonly (double minLat, double maxLat, double minLon, double maxLon) _astanaBounds = (51, 52, 71, 72);
        private readonly (double minLat, double maxLat, double minLon, double maxLon) _shymkentBounds = (42, 43, 69, 70);

        public SRTMDownloadDialog(double currentLat = 43.238, double currentLon = 76.945)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateCacheInfo()
        {
            long cacheSize = SRTMService.Instance.GetCacheSize();
            CacheInfoText.Text = $"В кэше: {cacheSize / 1024.0 / 1024.0:F1} MB";
        }

        private void RegionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private (double minLat, double maxLat, double minLon, double maxLon) GetSelectedBounds()
        {
            if (RegionComboBox.SelectedItem is ComboBoxItem item)
            {
                return item.Tag?.ToString() switch
                {
                    "KZ" => _kzBounds,
                    "Almaty" => _almatyBounds,
                    "Astana" => _astanaBounds,
                    "Shymkent" => _shymkentBounds,
                    "Current" => ((int)_currentLat, (int)_currentLat + 1, (int)_currentLon, (int)_currentLon + 1),
                    _ => ((int)_currentLat, (int)_currentLat + 1, (int)_currentLon, (int)_currentLon + 1)
                };
            }
            return ((int)_currentLat, (int)_currentLat + 1, (int)_currentLon, (int)_currentLon + 1);
        }

        private int CalculateTiles((double minLat, double maxLat, double minLon, double maxLon) bounds)
        {
            int latTiles = (int)(bounds.maxLat - bounds.minLat);
            int lonTiles = (int)(bounds.maxLon - bounds.minLon);
            return Math.Max(1, latTiles * lonTiles);
        }

        private async void DownloadButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (43 строк) ...
            throw new NotImplementedException();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }
    }
}