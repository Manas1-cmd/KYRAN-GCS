using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

using static SimpleDroneGCS.Helpers.Loc;

namespace SimpleDroneGCS.UI.Dialogs
{
    public partial class AppMessageBox : Window
    {
        public string TitleText { get; }
        public string SubTitleText { get; }
        public Visibility SubTitleVisibility { get; }

        public string MessageText { get; }
        public string HintText { get; }
        public Visibility HintVisibility { get; }

        public string IconText { get; }
        public SolidColorBrush AccentBrush { get; }
        public Color AccentColor { get; }

        public string OkText { get; }
        public string CancelText { get; }

        private AppMessageBox(string title, string message, AppMessageBoxType type,
                              string okText, string cancelText, bool showCancel,
                              string subtitle = null, string hint = null)
        {
            // ... реализация (24 строк) ...
            throw new NotImplementedException();
        }

        private static (string icon, Color accent) GetVisuals(AppMessageBoxType type)
        {
            // ... реализация (16 строк) ...
            throw new NotImplementedException();
        }

        private void Ok_Click(object sender, RoutedEventArgs e) => DialogResult = true;
        private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
        private void Close_Click(object sender, RoutedEventArgs e) => DialogResult = false;

        public AppMessageBoxResult Result { get; private set; } = AppMessageBoxResult.Cancel;

        private void Yes_Click(object sender, RoutedEventArgs e)
        {
            Result = AppMessageBoxResult.Yes;
            DialogResult = true;
        }

        private void No_Click(object sender, RoutedEventArgs e)
        {
            Result = AppMessageBoxResult.No;
            DialogResult = true;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        public static bool Show(Window owner, string title, string message, AppMessageBoxType type,
                                string okText = "OK", string cancelText = null, bool showCancel = false,
                                string subtitle = null, string hint = null)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        public static void ShowError(string message, Window owner = null, string subtitle = null, string hint = null)
            => Show(owner, Get("MsgBox_Error"), message, AppMessageBoxType.Error, okText: "OK", showCancel: false, subtitle: subtitle, hint: hint);

        public static void ShowWarning(string message, Window owner = null, string subtitle = null, string hint = null)
            => Show(owner, Get("MsgBox_Warning"), message, AppMessageBoxType.Warning, okText: "OK", showCancel: false, subtitle: subtitle, hint: hint);

        public static void ShowInfo(string message, Window owner = null, string subtitle = null, string hint = null)
            => Show(owner, Get("MsgBox_Info"), message, AppMessageBoxType.Info, okText: "OK", showCancel: false, subtitle: subtitle, hint: hint);

        public static void ShowSuccess(string message, Window owner = null, string subtitle = null, string hint = null)
            => Show(owner, Get("MsgBox_Success"), message, AppMessageBoxType.Success, okText: "OK", showCancel: false, subtitle: subtitle, hint: hint);

        public static bool ShowConfirm(string message, Window owner = null, string subtitle = null, string hint = null)
            => Show(owner, Get("MsgBox_Confirm"), message, AppMessageBoxType.Confirm,
                    okText: Get("MsgBox_Yes"), cancelText: Get("MsgBox_No"), showCancel: true, subtitle: subtitle, hint: hint);
        public static AppMessageBoxResult ShowYesNoCancel(string message, Window owner = null,
            string subtitle = null, string yesText = "Да", string noText = "Нет", string cancelText = null)
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }
    }
}
