using SimpleDroneGCS.Models;
using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace SimpleDroneGCS.Views
{
    public partial class VehicleSelectionWindow : Window
    {
        public VehicleType SelectedVehicle { get; private set; }
        public bool SelectionMade { get; private set; }

        public VehicleSelectionWindow()
        {
            InitializeComponent();
            Debug.WriteLine("[VehicleSelection] Window created");
            SelectionMade = false;
        }

        private void VehicleCard_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }
    }
}