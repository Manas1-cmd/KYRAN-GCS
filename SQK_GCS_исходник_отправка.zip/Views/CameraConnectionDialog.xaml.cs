using SimpleDroneGCS.Properties;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SimpleDroneGCS.Views
{
    public partial class CameraConnectionDialog : Window
    {
        
        private static readonly Dictionary<string, string> RtspTemplates = new()
        {
            ["Z30T"] = "rtsp://{0}:{1}/chn0",
            ["Z30D"] = "rtsp://{0}:{1}/chn0",
            ["Z40DT"] = "rtsp://{0}:{1}/chn0",
            ["Custom"] = "rtsp://{0}:{1}"
        };

        private static readonly Dictionary<string, int> TcpPorts = new()
        {
            ["Z30T"] = 2000,
            ["Z30D"] = 2000,
            ["Z40DT"] = 2000,
            ["Custom"] = 2000
        };

        private static readonly Dictionary<string, int> RtspPorts = new()
        {
            ["Z30T"] = 554,
            ["Z30D"] = 554,
            ["Z40DT"] = 554,
            ["Custom"] = 554
        };

        private static readonly Dictionary<string, string> CameraDescriptions = new()
        {
            ["Z30T"] = "📷 30x Zoom | Sony Sensor | 🎯 Tracking | 🔥 IR | 📏 LRF",
            ["Z30D"] = "📷 30x Zoom | Dual Sensor | 🔥 IR | 📏 LRF",
            ["Z40DT"] = "📷 40x Zoom | Dual Sensor | 🔥 IR | 📏 LRF",
            ["Custom"] = "Пользовательская конфигурация"
        };

        private static readonly Dictionary<string, string> DefaultIPs = new()
        {
            ["Z30T"] = "192.168.144.68",
            ["Z30D"] = "192.168.144.68",
            ["Z40DT"] = "192.168.144.68",
            ["Custom"] = "192.168.1.1"
        };

        private bool _isInitialized = false;

        public CameraConnectionSettings ConnectionSettings { get; private set; }

        public CameraConnectionDialog()
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void PresetComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }

        private void IpAddress_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isInitialized) UpdateRtspUrl();
        }

        private void RtspPort_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isInitialized) UpdateRtspUrl();
        }

        private void UpdateRtspUrl()
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        private void LoadSavedSettings()
        {
            // ... реализация (40 строк) ...
            throw new NotImplementedException();
        }

        private void SaveSettings()
        {
            // ... реализация (17 строк) ...
            throw new NotImplementedException();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (29 строк) ...
            throw new NotImplementedException();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 1) DragMove();
        }

    }

    public class CameraConnectionSettings
    {
        public string CameraIP { get; set; } = "192.168.144.68";
        public int TcpPort { get; set; } = 2000;
        public string RtspUrl { get; set; } = "rtsp://192.168.144.68:554/chn0";
        public string CameraType { get; set; } = "Z30T";
    }
}
