using SimpleDroneGCS.Controls;
using SimpleDroneGCS.UI.Dialogs;
using System.Net;
using System.Windows;

namespace SimpleDroneGCS.Views
{
    public partial class UdpConnectionDialog : Window
    {
        public string LocalIp { get; private set; } = "0.0.0.0";
        public int LocalPort { get; private set; } = 14550;
        public string? HostIp { get; private set; }
        public int? HostPort { get; private set; }
        public bool IsConfirmed { get; private set; }

        public UdpConnectionDialog()
        {
            InitializeComponent();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (37 строк) ...
            throw new NotImplementedException();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = false;
            Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            IsConfirmed = false;
            Close();
        }

        private void PresetDrone_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private void PresetSimulator_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private void PresetListen_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }
    }
}
