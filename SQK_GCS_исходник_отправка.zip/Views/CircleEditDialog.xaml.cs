using System.Windows;
using System.Windows.Input;

namespace SimpleDroneGCS.Views
{
    public partial class CircleEditDialog : Window
    {
        public double Radius { get; private set; }
        public double Altitude { get; private set; }
        public bool AutoNext { get; private set; }
        public bool Clockwise { get; private set; }

        private const double MIN_RADIUS = 150.0;

        public CircleEditDialog(string title, double radius, double altitude, bool autoNext, bool clockwise)
        {
            // ... реализация (17 строк) ...
            throw new NotImplementedException();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 1)
                DragMove();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (33 строк) ...
            throw new NotImplementedException();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
