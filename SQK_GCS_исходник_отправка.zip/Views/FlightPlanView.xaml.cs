using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsPresentation;
using SimpleDroneGCS.Models;
using SimpleDroneGCS.Services;
using SimpleDroneGCS.UI.Dialogs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

using static SimpleDroneGCS.Helpers.Loc;

namespace SimpleDroneGCS.Views
{
    public partial class FlightPlanView : UserControl
    {

        private Window OwnerWindow => Window.GetWindow(this) ?? Application.Current?.MainWindow;
        private VehicleType _currentVehicleType = VehicleType.Copter;

        private ObservableCollection<WaypointItem> _waypoints;
        private GMapMarker _currentDragMarker;
        private WaypointItem _selectedWaypoint;
        private double _waypointRadius = 80;
        private WaypointItem _radiusDragWaypoint = null;
        private bool _isRadiusDragging = false;
        private TextBlock _radiusTooltip = null;
        private MAVLinkService _mavlinkService;
        private GMapMarker _droneMarker = null;
        private WaypointItem _homePosition = null;
        private bool _isInitialized = false;
        private Dictionary<VehicleType, List<WaypointItem>> _missionsByType = new();
        private Dictionary<VehicleType, WaypointItem> _homeByType = new();
        private Dictionary<VehicleType, WaypointItem> _startByType = new();
        private Dictionary<VehicleType, WaypointItem> _landingByType = new();
        private DispatcherTimer _droneUpdateTimer;
        private bool _isSettingHomeMode = false;
        private double _takeoffAltitude = 10;
        private double _rtlAltitude = 15;
        private bool _wasArmed = false;
        private bool _homeLockedFromArm = false;
        private bool? _lastDisplayedArmed = null;
        private bool? _lastNextBtnVisible = null;
        private string _lastDisplayedMode = null;
        private VehicleType? _lastSpeedLabelType = null;
        private byte _lastGpsFixType = 255;
        private SrtmElevationProvider _elevationProvider = new();
        private Dictionary<WaypointItem, GMapMarker> _resizeHandles = new();

        private DispatcherTimer _telemetryTimer;
        private DispatcherTimer _connectionTimer;
        private DateTime _connectionStartTime;
        private bool _wasConnected = false;

        private WaypointItem _startCircle;
        private WaypointItem _landingCircle;
        private double _vtolTakeoffAltitude = 30;
        private double _vtolLandAltitude = 30;
        private bool _isMissionFrozen = false;
        private bool _isDataTabActive = true;

        public FlightPlanView(MAVLinkService mavlinkService = null)
        {
            // ... реализация (145 строк) ...
            throw new NotImplementedException();
        }

        private void InitializePlanMap()
        {
            // ... реализация (53 строк) ...
            throw new NotImplementedException();
        }

        private bool CheckInternetConnection()
        {
            // ... реализация (29 строк) ...
            throw new NotImplementedException();
        }

        private void DownloadMapButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void MapTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... реализация (38 строк) ...
            throw new NotImplementedException();
        }

        private void SetHomeAtPosition(double lat, double lon)
        {
            // ... реализация (27 строк) ...
            throw new NotImplementedException();
        }
        private void PlanMap_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (49 строк) ...
            throw new NotImplementedException();
        }

        private void AddMarkerToMap(WaypointItem waypoint)
        {
            // ... реализация (35 строк) ...
            throw new NotImplementedException();
        }

        private UIElement CreateMarkerShape(WaypointItem waypoint)
        {
            // ... реализация (62 строк) ...
            throw new NotImplementedException();
        }

        private ToolTip CreateWaypointTooltip(WaypointItem wp)
        {
            // ... реализация (52 строк) ...
            throw new NotImplementedException();
        }

        private StackPanel CreateTooltipRow(string label, string value)
        {
            // ... реализация (17 строк) ...
            throw new NotImplementedException();
        }

        private double MetersToPixels(double meters, double latitude, double zoom)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void SetupMarkerDragDrop(GMapMarker marker, WaypointItem waypoint)
        {
            // ... реализация (53 строк) ...
            throw new NotImplementedException();
        }

        private void SelectWaypoint(WaypointItem wp)
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        private GMapMarker _tooltipMarker = null;

        private void ResizeHandle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (15 строк) ...
            throw new NotImplementedException();
        }

        private void CreateRadiusTooltip()
        {
            // ... реализация (27 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateRadiusTooltip(PointLatLng position, double radius)
        {
            // ... реализация (17 строк) ...
            throw new NotImplementedException();
        }

        private void HideRadiusTooltip()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private double GetMinRadius()
        {
            return _currentVehicleType == VehicleType.QuadPlane ? 80 : 5;
        }

        private void EndRadiusDrag()
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void CreateResizeHandle(WaypointItem waypoint)
        {
            // ... реализация (72 строк) ...
            throw new NotImplementedException();
        }

        private PointLatLng CalculatePointAtDistance(double lat, double lon, double bearingDeg, double distanceKm)
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private void RemoveWaypoint(WaypointItem waypoint)
        {
            // ... реализация (39 строк) ...
            throw new NotImplementedException();
        }

        private void RenumberWaypoints()
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateRoute()
        {
            // ... реализация (146 строк) ...
            throw new NotImplementedException();
        }

        private void DrawVtolSpecialPoints()
        {
            // ... реализация (81 строк) ...
            throw new NotImplementedException();
        }

        private void DrawArcOnSpecialCircle(WaypointItem wp, PointLatLng entryPoint, PointLatLng exitPoint, Color color)
        {
            // ... реализация (44 строк) ...
            throw new NotImplementedException();
        }

        private void AddSpecialCircleMarker(WaypointItem wp, string label, Color dotColor, Color circleColor)
        {
            // ... реализация (160 строк) ...
            throw new NotImplementedException();
        }

        private ToolTip CreateCircleTooltip(WaypointItem wp, string label)
        {
            // ... реализация (31 строк) ...
            throw new NotImplementedException();
        }

        private void DrawVtolLine(PointLatLng from, PointLatLng to, Color color, bool dashed)
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        private (PointLatLng, PointLatLng) GetExternalTangentPoints(
            double lat1, double lon1, double r1, bool cw1,
            double lat2, double lon2, double r2, bool cw2)
        {
            double dist = CalculateDistanceLatLng(lat1, lon1, lat2, lon2);
            double bearing = CalculateBearing(lat1, lon1, lat2, lon2);

            double exitOffset = cw1 ? -90 : 90;
            double entryOffset = cw2 ? -90 : 90;

            bool sameSide = (cw1 == cw2);
            double tangentAngle = 0;

            if (sameSide)
            {

                if (dist > Math.Abs(r1 - r2))
                {
                    double sinAlpha = (r1 - r2) / dist;
                    sinAlpha = Math.Max(-1, Math.Min(1, sinAlpha));
                    tangentAngle = Math.Asin(sinAlpha) * 180 / Math.PI;
                }

                double exitAngle = bearing + exitOffset + tangentAngle;
                double entryAngle = bearing + entryOffset + tangentAngle;

                return (
                    CalculatePointAtDistance(lat1, lon1, exitAngle, r1 / 1000.0),
                    CalculatePointAtDistance(lat2, lon2, entryAngle, r2 / 1000.0)
                );
            }
            else
            {

                if (dist > (r1 + r2))
                {
                    double sinAlpha = (r1 + r2) / dist;
                    sinAlpha = Math.Max(-1, Math.Min(1, sinAlpha));
                    tangentAngle = Math.Asin(sinAlpha) * 180 / Math.PI;
                }

                double crossSign = cw1 ? 1 : -1;
                double exitAngle = bearing + exitOffset + crossSign * tangentAngle;
                double entryAngle = bearing + entryOffset + crossSign * tangentAngle;

                return (
                    CalculatePointAtDistance(lat1, lon1, exitAngle, r1 / 1000.0),
                    CalculatePointAtDistance(lat2, lon2, entryAngle, r2 / 1000.0)
                );
            }
        }

        private (PointLatLng, PointLatLng) GetExternalTangentPoints(
            double lat1, double lon1, double r1,
            double lat2, double lon2, double r2)
        {
            return GetExternalTangentPoints(lat1, lon1, r1, true, lat2, lon2, r2, true);
        }

        private PointLatLng GetNearEdgePoint(double circleLat, double circleLon, double circleRadius,
                                              double pointLat, double pointLon)
        {
            double bearing = CalculateBearing(circleLat, circleLon, pointLat, pointLon);
            return CalculatePointAtDistance(circleLat, circleLon, bearing, circleRadius / 1000.0);
        }

        private void UpdateRouteOnly()
        {
            // ... реализация (113 строк) ...
            throw new NotImplementedException();
        }

        private double CalculateBearing(double lat1, double lon1, double lat2, double lon2)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private double CalculateDistanceLatLng(double lat1, double lon1, double lat2, double lon2)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void RadiusSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private void DrawArcOnWaypoint(WaypointItem wp, PointLatLng entryPoint, PointLatLng exitPoint)
        {
            // ... реализация (44 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateStatistics()
        {
            // ... реализация (31 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateMissionStrip()
        {
            // ... реализация (28 строк) ...
            throw new NotImplementedException();
        }

        public void HighlightMissionSeq(int seq)
        {
            // ... реализация (35 строк) ...
            throw new NotImplementedException();
        }

        private double CalculateDistance(WaypointItem wp1, WaypointItem wp2)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private double ToRadians(double degrees) => degrees * Math.PI / 180.0;

        private void UpdateWaypointsList()
        {
            // ... реализация (24 строк) ...
            throw new NotImplementedException();
        }

        private Border CreateWaypointCard(WaypointItem wp)
        {
            // ... реализация (144 строк) ...
            throw new NotImplementedException();
        }

        private (string badge, string name, Color color) GetCommandBadgeInfo(string commandType, bool isVtol = false)
        {
            string prefix = isVtol ? "Q_" : "";

            return commandType switch
            {
                "WAYPOINT" => ("W", $"{prefix}{Get("CmdShort_Waypoint")}", Color.FromRgb(34, 197, 94)),
                "LOITER_UNLIM" => ("L", $"{prefix}{Get("CmdShort_Loiter")}", Color.FromRgb(59, 130, 246)),
                "LOITER_TIME" => ("LT", $"{prefix}{Get("CmdShort_LoiterTime")}", Color.FromRgb(59, 130, 246)),
                "LOITER_TURNS" => ("LR", $"{prefix}{Get("CmdShort_LoiterTurns")}", Color.FromRgb(59, 130, 246)),
                "TAKEOFF" => ("T", Get("CmdShort_Takeoff"), Color.FromRgb(16, 185, 129)),
                "LAND" => ("LD", $"{prefix}{Get("CmdShort_Land")}", Color.FromRgb(249, 115, 22)),
                "DELAY" => ("D", $"{prefix}{Get("CmdShort_Delay")}", Color.FromRgb(139, 92, 246)),
                "CHANGE_SPEED" => ("S", $"{prefix}{Get("CmdShort_Speed")}", Color.FromRgb(234, 179, 8)),
                "RETURN_TO_LAUNCH" => ("R", Get("CmdShort_RTL"), Color.FromRgb(239, 68, 68)),
                "SPLINE_WP" => ("SP", Get("CmdShort_Spline"), Color.FromRgb(20, 184, 166)),
                _ => ("W", $"{prefix}{Get("CmdShort_Waypoint")}", Color.FromRgb(34, 197, 94))
            };
        }

        private void OpenWaypointEditDialog(WaypointItem wp)
        {
            // ... реализация (53 строк) ...
            throw new NotImplementedException();
        }

        private async void TryRealTimeMissionUpdate(WaypointItem changedWp = null)
        {
            // ... реализация (36 строк) ...
            throw new NotImplementedException();
        }

        private dynamic[] GetCommandsForVehicleType()
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        private void AddHomePosition()
        {
            // ... реализация (39 строк) ...
            throw new NotImplementedException();
        }

        private void AddHomeMarkerToMap(WaypointItem home)
        {
            // ... реализация (21 строк) ...
            throw new NotImplementedException();
        }

        private void DataTabButton_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private void MissionTabButton_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private void DrawCompassTicks()
        {
            // ... реализация (39 строк) ...
            throw new NotImplementedException();
        }

        private void SetHomeButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private UIElement CreateHomeMarkerShape()
        {
            // ... реализация (27 строк) ...
            throw new NotImplementedException();
        }

        private ControlTemplate CreateRoundedTextBoxTemplate()
        {
            // ... реализация (20 строк) ...
            throw new NotImplementedException();
        }

        private void CommandCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private void AltitudeBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // ... реализация (13 строк) ...
            throw new NotImplementedException();
        }

        private void DelayBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private void MoveUpButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private void MoveDownButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private void ZoomSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private void MissionScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {

        }

        private void RefreshMarkers()
        {
            // ... реализация (76 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateSpecialCircleSize(WaypointItem wp, string label)
        {
            // ... реализация (22 строк) ...
            throw new NotImplementedException();
        }

        private void AddWaypointButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        private void ExecuteButton_Click(object sender, RoutedEventArgs e)
        {
            AppMessageBox.ShowInfo(Get("Msg_InDevelopment"), owner: OwnerWindow, subtitle: Get("Msg_InDevelopmentSub"));
        }

        private void LoiterButton_Click(object sender, RoutedEventArgs e)
        {
            AppMessageBox.ShowInfo(Get("Msg_InDevelopment"), owner: OwnerWindow, subtitle: Get("Msg_InDevelopmentSub"));
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            AppMessageBox.ShowInfo(Get("Msg_InDevelopment"), owner: OwnerWindow, subtitle: Get("Msg_InDevelopmentSub"));
        }

        private void ToggleButton_Click(object sender, RoutedEventArgs e)
        {
            AppMessageBox.ShowInfo(Get("Msg_InDevelopment"), owner: OwnerWindow, subtitle: Get("Msg_InDevelopmentSub"));
        }

        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (76 строк) ...
            throw new NotImplementedException();
        }

        private async void DownloadButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (216 строк) ...
            throw new NotImplementedException();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (31 строк) ...
            throw new NotImplementedException();
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (213 строк) ...
            throw new NotImplementedException();
        }

        private string ConvertMAVCmdToCommandType(ushort cmd)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (27 строк) ...
            throw new NotImplementedException();
        }

        private void SaveMissionToFile(string filename)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string fullPath = System.IO.Path.Combine(desktopPath, filename);
            SaveMissionToPath(fullPath);
        }

        private void SaveMissionToPath(string fullPath)
        {
            // ... реализация (28 строк) ...
            throw new NotImplementedException();
        }

        private (double p1, double p2, double p3, double p4) GetCommandParams(WaypointItem wp)
        {

            double signedRadius = wp.Clockwise ? Math.Abs(wp.Radius) : -Math.Abs(wp.Radius);

            switch (wp.CommandType)
            {
                case "VTOL_TRANSITION_FW":
                    return (4, 0, 0, 0);
                case "VTOL_TRANSITION_MC":
                    return (3, 0, 0, 0);
                case "LOITER_TIME":
                    return (wp.Delay, 0, signedRadius, 0);
                case "LOITER_TURNS":
                    return (wp.LoiterTurns, 0, signedRadius, 0);
                case "LOITER_UNLIM":
                    return (0, 0, signedRadius, 0);
                case "CHANGE_SPEED":
                    return (1, wp.Delay, -1, 0);
                case "SPLINE_WP":
                    return (wp.Delay, 0, 0, 0);
                case "WAYPOINT":
                    return (wp.Delay, 0, 0, 0);
                case "DELAY":
                    return (wp.Delay, 0, 0, 0);
                default:
                    return (wp.Delay, 0, 0, 0);
            }
        }

        private ushort ConvertCommandTypeToMAVCmd(string commandType)
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        private void PlanMap_MouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private GMapMarker CreateDroneMarker(PointLatLng position)
        {
            // ... реализация (59 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateDronePosition(object sender, EventArgs e)
        {
            // ... реализация (54 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateDroneInfoPanel(Telemetry telemetry)
        {
            // ... реализация (38 строк) ...
            throw new NotImplementedException();
        }

        private void SetHomeFromDronePosition(double lat, double lon)
        {
            // ... реализация (27 строк) ...
            throw new NotImplementedException();
        }

        public List<WaypointItem> GetFullMission()
        {
            // ... реализация (151 строк) ...
            throw new NotImplementedException();
        }

        private void SaveCurrentMissionForType()
        {
            // ... реализация (75 строк) ...
            throw new NotImplementedException();
        }

        private void LoadMissionForType(VehicleType type)
        {
            // ... реализация (133 строк) ...
            throw new NotImplementedException();
        }

        private void VehicleTypeSelector_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private ContextMenu BuildVehicleTypeMenu()
        {
            // ... реализация (68 строк) ...
            throw new NotImplementedException();
        }

        private static UIElement BuildVehicleMenuHeader(string iconPath, string title, string shortCode)
        {
            // ... реализация (47 строк) ...
            throw new NotImplementedException();
        }

        private void VehicleTypeMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (41 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateVehicleTypeDisplay()
        {
            // ... реализация (32 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateQuickModeButtons()
        {
            // ... реализация (19 строк) ...
            throw new NotImplementedException();
        }

        private void DownloadSRTM_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateWaypointRadiusVisual(WaypointItem wp)
        {
            // ... реализация (39 строк) ...
            throw new NotImplementedException();
        }

        private void PlanMap_OnMapZoomChanged()
        {
            // ... реализация (26 строк) ...
            throw new NotImplementedException();
        }

        private void PlanMap_MouseMove(object sender, MouseEventArgs e)
        {
            // ... реализация (62 строк) ...
            throw new NotImplementedException();
        }

        private void LoiterBtn_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private void ResumeBtn_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        private void StartBtn_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private void RtlBtn_Click(object sender, MouseButtonEventArgs e)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private void ShowNotConnectedMessage()
        {
            AppMessageBox.ShowWarning(Get("Msg_DroneNotConnected"), owner: OwnerWindow);
        }

        private void OnTelemetryReceived(object sender, Telemetry telemetry)
        {

        }

        private void UpdateTelemetryUI(object sender, EventArgs e)
        {
            // ... реализация (67 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateGpsStatus(Telemetry telemetry)
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateMotorValues(Telemetry telemetry)
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateFlightModeOverlay(Telemetry telemetry)
        {
            // ... реализация (23 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateArmButton(Telemetry telemetry)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateNextWaypointButtonVisibility(Telemetry telemetry)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private void UpdateConnectionTimer(object sender, EventArgs e)
        {
            // ... реализация (19 строк) ...
            throw new NotImplementedException();
        }

        private void PopulateFlightModes()
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void FlightModeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void ArmButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (35 строк) ...
            throw new NotImplementedException();
        }

        private void QuickMode_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private void CalibrateButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (35 строк) ...
            throw new NotImplementedException();
        }

        private async void ActivateMissionButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (64 строк) ...
            throw new NotImplementedException();
        }

        private string FormatDistance(double meters)
        {
            return $"{meters:F0} м";
        }

        private void InitializeStartCircle()
        {
            // ... реализация (29 строк) ...
            throw new NotImplementedException();
        }

        private void InitializeLandingCircle()
        {
            // ... реализация (28 строк) ...
            throw new NotImplementedException();
        }

        private async void FreezeResumeMission_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (96 строк) ...
            throw new NotImplementedException();
        }

        private void ShowStatusMessage(string message)
        {
            System.Diagnostics.Debug.WriteLine($"[STATUS] {message}");
            AppMessageBox.ShowInfo(message, owner: OwnerWindow);
        }

        private void ResumeMissionButton_Click(object sender, RoutedEventArgs e)
        {
            // ... реализация (34 строк) ...
            throw new NotImplementedException();
        }
    }

    public class WaypointItem : INotifyPropertyChanged
    {
        private int _number;
        private double _delay;
        private double _latitude;
        private double _longitude;
        private double _altitude;
        private string _commandType;
        private double _radius;
        public GMapMarker Marker { get; set; }

        public Grid ShapeGrid { get; set; }
        public Ellipse RadiusCircle { get; set; }

        public int Number
        {
            get => _number;
            set { _number = value; OnPropertyChanged(); }
        }

        public double Latitude
        {
            get => _latitude;
            set { _latitude = value; OnPropertyChanged(); }
        }

        public double Longitude
        {
            get => _longitude;
            set { _longitude = value; OnPropertyChanged(); }
        }

        public double Altitude
        {
            get => _altitude;
            set { _altitude = value; OnPropertyChanged(); }
        }

        public string CommandType
        {
            get => _commandType;
            set { _commandType = value; OnPropertyChanged(); }
        }

        public double Radius
        {
            get => _radius;
            set { _radius = value; OnPropertyChanged(); }
        }
        public double Delay
        {
            get => _delay;
            set { _delay = value; OnPropertyChanged(); }
        }

        private int _loiterTurns;
        public int LoiterTurns
        {
            get => _loiterTurns;
            set { _loiterTurns = value; OnPropertyChanged(); }
        }

        private bool _autoNext = true;

        public bool AutoNext
        {
            get => _autoNext;
            set { _autoNext = value; OnPropertyChanged(); }
        }

        private bool _clockwise = true;

        public bool Clockwise
        {
            get => _clockwise;
            set { _clockwise = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }

}