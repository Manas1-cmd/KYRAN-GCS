using System;
using System.Diagnostics;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleDroneGCS.Services
{
    
    public class ViewProCameraService : IDisposable
    {

        private const byte HEADER_55 = 0x55;
        private const byte HEADER_AA = 0xAA;
        private const byte HEADER_DC = 0xDC;
        private const byte TCP_EB = 0xEB;
        private const byte TCP_90 = 0x90;

        private const byte FRAME_COMBINED = 0x30;
        private const byte FRAME_QUERY = 0x15;
        private const byte FRAME_FEEDBACK = 0x40;
        private const byte FRAME_ACK = 0xAC;

        private const byte A1_MOTOR_CTRL = 0x00;
        private const byte A1_SPEED = 0x01;
        private const byte A1_HOME = 0x04;
        private const byte A1_TRACKING = 0x06;
        private const byte A1_ANGLE_ABS = 0x0B;
        private const byte A1_RC = 0x0D;          
        private const byte A1_NO_CHANGE = 0x0F;
        private const byte A1_PITCH_DOWN = 0x12;

        private const int PWM_CENTER = 1500;
        private const int PWM_MIN = 1000;
        private const int PWM_MAX = 2000;

        private const byte C1_STOP = 0x01;
        private const byte C1_ZOOM_OUT = 0x08;
        private const byte C1_ZOOM_IN = 0x09;
        private const byte C1_FOCUS_FAR = 0x0A;
        private const byte C1_FOCUS_NEAR = 0x0B;
        private const byte C1_IR_WHITE = 0x0E;
        private const byte C1_IR_BLACK = 0x0F;
        private const byte C1_IR_RAINBOW = 0x12;
        private const byte C1_PHOTO = 0x13;
        private const byte C1_REC_START = 0x14;
        private const byte C1_REC_STOP = 0x15;
        private const byte C1_AUTO_FOCUS = 0x19;
        private const byte C1_IR_DZOOM_IN = 0x1B;
        private const byte C1_IR_DZOOM_OUT = 0x1C;

        private const byte LRF_NONE = 0x00;
        private const byte LRF_SINGLE = 0x01;      
        private const byte LRF_CONTINUOUS = 0x02;   
        private const byte LRF_STOP = 0x03;         

        public const byte SRC_EO = 0x01;
        public const byte SRC_IR = 0x02;
        public const byte SRC_EO_IR_PIP = 0x03;
        public const byte SRC_IR_EO_PIP = 0x04;
        public const byte SRC_FUSION = 0x05;

        private const byte E1_NONE = 0x00;
        private const byte E1_STOP = 0x01;
        private const byte E1_SEARCH = 0x02;
        private const byte E1_START = 0x03;
        private const byte E1_AI_TOGGLE = 0x05;

        public const byte VIDEO_EO1 = SRC_EO;
        public const byte VIDEO_IR = SRC_IR;
        public const byte VIDEO_EO_IR_PIP = SRC_EO_IR_PIP;
        public const byte VIDEO_IR_EO_PIP = SRC_IR_EO_PIP;
        public const byte VIDEO_FUSION = SRC_FUSION;

        public event EventHandler<bool>? ConnectionChanged;
        public event EventHandler<GimbalAngles>? AnglesReceived;
        public event EventHandler<float>? DistanceReceived;
        public event EventHandler<string>? ErrorOccurred;
        public event EventHandler<byte[]>? DataReceived;
        public event Action<string>? StatusChanged;

        public bool IsConnected => _tcpClient?.Connected ?? false;
        public string IpAddress { get; set; } = "192.168.1.108";
        public int Port { get; set; } = 2000;
        public int RtspPort { get; set; } = 554;
        public GimbalAngles CurrentAngles { get; private set; } = new GimbalAngles();
        public float CurrentDistance { get; private set; } = 0;
        public bool IsRecording { get; private set; } = false;
        public string RtspUrl => $"rtsp://{IpAddress}:{RtspPort}/stream0";
        public long TotalBytesReceived { get; private set; } = 0;

        private TcpClient? _tcpClient;
        private NetworkStream? _networkStream;
        private CancellationTokenSource? _cts;
        private Task? _receiveTask;
        private Task? _heartbeatTask;
        private readonly object _sendLock = new object();
        private bool _disposed = false;
        private byte _frameCounter = 0;
        private byte _currentSensor = SRC_EO;
        private volatile bool _userActive = false;
        private DateTime _lastUserCmd = DateTime.MinValue;

        public async Task<bool> ConnectAsync(string ip, int port)
        {
            IpAddress = ip;
            Port = port;
            return await ConnectAsync();
        }

        public async Task<bool> ConnectAsync()
        {
            // ... реализация (42 строк) ...
            throw new NotImplementedException();
        }

        public void Disconnect()
        {
            // ... реализация (15 строк) ...
            throw new NotImplementedException();
        }

        private byte[] BuildSerialPacket(byte frameId, byte[] data)
        {
            // ... реализация (19 строк) ...
            throw new NotImplementedException();
        }

        private byte[] WrapTcp(byte[] serial)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private bool SendPacket(byte[] serialPacket)
        {
            // ... реализация (21 строк) ...
            throw new NotImplementedException();
        }

        private bool SendFrame30(byte[] a1, ushort c1, byte[] e1)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private bool SendQuery(byte queryType)
        {
            return SendPacket(BuildSerialPacket(FRAME_QUERY, new byte[] { queryType }));
        }

        private byte[] BuildA1(byte mode, int yaw = 0, int pitch = 0)
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private byte[] BuildA1_RC(int yawPwm, int pitchPwm)
        {
            return BuildA1(A1_RC, Math.Clamp(yawPwm, PWM_MIN, PWM_MAX), Math.Clamp(pitchPwm, PWM_MIN, PWM_MAX));
        }

        private ushort BuildC1(byte cmd = 0, byte sensor = 0, byte zoomSpd = 5, byte lrf = 0)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private byte[] BuildE1(byte cmd = 0, byte x = 0, byte y = 0)
            => new byte[] { cmd, x, y };

        private async Task HeartbeatLoop(CancellationToken ct)
        {
            // ... реализация (20 строк) ...
            throw new NotImplementedException();
        }

        public void SendHeartbeat() =>
            SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(), BuildE1());

        public void SendMotorOn()
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        public void SendMotorOff()
        {
            byte[] a1 = BuildA1(A1_MOTOR_CTRL);
            a1[2] = 0x01;
            SendFrame30(a1, BuildC1(), BuildE1());
        }

        public void SetGimbalSpeed(int yawPct, int pitchPct)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public bool SetGimbalAngles(int yawPwm, int pitchPwm)
        {
            _userActive = true;
            _lastUserCmd = DateTime.UtcNow;
            return SendFrame30(BuildA1_RC(yawPwm, pitchPwm), BuildC1(), BuildE1());
        }

        public bool SetAbsoluteAngle(float yawDeg, float pitchDeg)
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void StopGimbal()
        {
            _userActive = false;
            SendFrame30(BuildA1_RC(PWM_CENTER, PWM_CENTER), BuildC1(), BuildE1());
        }

        public bool ReturnToCenter()
        {
            _userActive = false;
            return SendFrame30(BuildA1(A1_HOME), BuildC1(), BuildE1());
        }

        public bool LookDown()
        {
            _userActive = false;
            return SendFrame30(BuildA1(A1_PITCH_DOWN), BuildC1(), BuildE1());
        }

        public bool GimbalCenter() => ReturnToCenter();
        public bool GimbalHome() => ReturnToCenter();
        public bool GimbalLookDown() => LookDown();
        public void GimbalControlSpeed(int y, int p) => SetGimbalSpeed(y, p);
        public void GimbalStop() => StopGimbal();
        public void MoveUp() => SetGimbalSpeed(0, 50);
        public void MoveDown() => SetGimbalSpeed(0, -50);
        public void MoveLeft() => SetGimbalSpeed(-50, 0);
        public void MoveRight() => SetGimbalSpeed(50, 0);
        public void StopMovement() => StopGimbal();

        public bool ZoomIn(int speed = 5)
        {
            _userActive = true; _lastUserCmd = DateTime.UtcNow;
            return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_ZOOM_IN, 0, (byte)Math.Clamp(speed, 1, 7)), BuildE1());
        }

        public bool ZoomOut(int speed = 5)
        {
            _userActive = true; _lastUserCmd = DateTime.UtcNow;
            return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_ZOOM_OUT, 0, (byte)Math.Clamp(speed, 1, 7)), BuildE1());
        }

        public bool ZoomStop() { _userActive = false; return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_STOP), BuildE1()); }
        public bool AutoFocus() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_AUTO_FOCUS), BuildE1());
        public bool FocusFar() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_FOCUS_FAR), BuildE1());
        public bool FocusNear() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_FOCUS_NEAR), BuildE1());
        public bool FocusStop() => ZoomStop();
        public bool FocusAuto() => AutoFocus();

        public bool TakePhoto() { StatusChanged?.Invoke("Фото"); return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_PHOTO), BuildE1()); }
        public bool StartRecording() { IsRecording = true; StatusChanged?.Invoke("Запись..."); return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_REC_START), BuildE1()); }
        public bool StopRecording() { IsRecording = false; StatusChanged?.Invoke("Стоп запись"); return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_REC_STOP), BuildE1()); }
        public bool ToggleRecording() => IsRecording ? StopRecording() : StartRecording();
        public bool RecordToggle() => ToggleRecording();

        public bool SetVideoSource(byte src) { _currentSensor = src; return SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(0, src), BuildE1()); }
        public bool SetVideoEO() => SetVideoSource(SRC_EO);
        public bool SetVideoIR() => SetVideoSource(SRC_IR);
        public bool SetVideoEO_IR_PIP() => SetVideoSource(SRC_EO_IR_PIP);
        public bool SetVideoIR_EO_PIP() => SetVideoSource(SRC_IR_EO_PIP);
        public bool SetVideoFusion() => SetVideoSource(SRC_FUSION);
        public bool SetVideoEO_IR_PiP() => SetVideoEO_IR_PIP();
        public bool SetVideoIR_EO_PiP() => SetVideoIR_EO_PIP();
        public bool SetSensorEO() => SetVideoEO();
        public bool SetSensorIR() => SetVideoIR();
        public bool SetSensorEO_IR_PIP() => SetVideoEO_IR_PIP();
        public bool SetSensorIR_EO_PIP() => SetVideoIR_EO_PIP();
        public bool SetSensorFusion() => SetVideoFusion();

        public bool SetIRPaletteWhiteHot() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_IR_WHITE), BuildE1());
        public bool SetIRPaletteBlackHot() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_IR_BLACK), BuildE1());
        public bool SetIRPaletteRainbow() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_IR_RAINBOW), BuildE1());
        public bool IRDigitalZoomIn() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_IR_DZOOM_IN), BuildE1());
        public bool IRDigitalZoomOut() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(C1_IR_DZOOM_OUT), BuildE1());
        public bool SetIrDigitalZoom(int level) { if (level > 1) return IRDigitalZoomIn(); return true; }

        public bool LRFMeasureSingle() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(0, _currentSensor, 0, LRF_SINGLE), BuildE1());

        public bool LRFMeasureContinuous() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(0, _currentSensor, 0, LRF_CONTINUOUS), BuildE1());

        public bool LRFStop() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(0, _currentSensor, 0, LRF_STOP), BuildE1());

        public bool StartTracking(byte src = SRC_EO) => SendFrame30(BuildA1(A1_TRACKING), BuildC1(0, src), BuildE1(E1_START));
        public bool StopTracking(byte src = SRC_EO) => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(0, src), BuildE1(E1_STOP));
        public bool EnableSearchMode() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(), BuildE1(E1_SEARCH));
        public bool ToggleAIDetection() => SendFrame30(BuildA1(A1_NO_CHANGE), BuildC1(), BuildE1(E1_AI_TOGGLE));

        public bool SetTrackingPoint(float nx, float ny)
        {
            byte x = (byte)Math.Clamp(nx * 255, 0, 255);
            byte y = (byte)Math.Clamp(ny * 255, 0, 255);
            return SendFrame30(BuildA1(A1_TRACKING), BuildC1(), BuildE1(E1_START, x, y));
        }

        public bool StartTrackingMode() => StartTracking();
        public bool StartTracking(double nx, double ny) => SetTrackingPoint((float)nx, (float)ny);
        public bool TrackAtScreenPosition(int sx, int sy, int sw, int sh) => SetTrackingPoint((float)sx / sw, (float)sy / sh);
        public bool TrackAtPosition(int sx, int sy, byte sz = 0) => TrackAtScreenPosition(sx, sy, 1920, 1080);
        public bool SetTrackingSize(byte s) => true;

        public bool SaveGimbalSettings() => true;
        public bool RestoreGimbalSettings() => true;
        public bool QuerySdCardStatus() => true;
        public bool QuerySdCardFreeSpace() => true;
        public bool QuerySdCardTotalCapacity() => true;
        public bool FormatSdCard() => true;
        public bool SetZoomLevel(int l) => true;

        private async Task ReceiveLoop(CancellationToken ct)
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        private void ParseReceivedData(byte[] data, int length)
        {
            // ... реализация (42 строк) ...
            throw new NotImplementedException();
        }

        private void ParseFeedback(byte[] data, int off, int len)
        {
            // ... реализация (24 строк) ...
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            Disconnect();
        }

    }

    public class GimbalAngles
    {
        public float Roll { get; set; }
        public float Pitch { get; set; }
        public float Yaw { get; set; }
    }
}
