using System;
using System.Collections.Generic;
using System.IO;

namespace SimpleDroneGCS.Services
{
    
    public class SrtmElevationProvider
    {
        private readonly string _srtmFolder;
        private readonly Dictionary<string, short[]> _cache = new();

        private const int SRTM3_SIZE = 1201;
        private const int SRTM1_SIZE = 3601;

        public SrtmElevationProvider()
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        public double? GetElevation(double lat, double lng)
        {
            // ... реализация (39 строк) ...
            throw new NotImplementedException();
        }

        private string GetFileName(double lat, double lng)
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        private short[] LoadFile(string filePath)
        {
            // ... реализация (20 строк) ...
            throw new NotImplementedException();
        }

        public bool HasDataFor(double lat, double lng)
        {
            string fileName = GetFileName(lat, lng);
            string filePath = Path.Combine(_srtmFolder, fileName);
            return File.Exists(filePath);
        }

        public string[] GetAvailableFiles()
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }
    }
}