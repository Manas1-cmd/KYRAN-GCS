using SimpleDroneGCS.Models;
using SimpleDroneGCS.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using static GMap.NET.Entity.OpenStreetMapRouteEntity;
using static MAVLink;
using System.Net;
using System.Net.Sockets;

using static SimpleDroneGCS.Helpers.Loc;

namespace SimpleDroneGCS.Services
{

    public class MAVLinkService
    {
        private SerialPort _serialPort;

        private System.Net.Sockets.UdpClient _udpClient;
        private System.Net.IPEndPoint _remoteEndPoint;
        private bool _isUdpMode;
        private CancellationTokenSource _udpCts;
        private bool _udpWaitingForFirstPacket;
        private bool _heartbeatReceived = false;

        private CancellationTokenSource _cts;
        private MavlinkParse _parser;
        private byte _packetSequence = 0;
        private DispatcherTimer _heartbeatTimer;
        private DispatcherTimer _telemetryRequestTimer;
        private DateTime _connectionStartTime = DateTime.MinValue;

        private List<WaypointItem> _plannedMission = null;
        public bool HasPlannedMission => _plannedMission != null && _plannedMission.Count > 0;
        public int PlannedMissionCount => _plannedMission?.Count ?? 0;

        private List<WaypointItem> _activeMission = null;
        public bool HasActiveMission => _activeMission != null && _activeMission.Count > 0;
        public List<WaypointItem> ActiveMission => _activeMission;

        private List<MAVLink.mavlink_mission_item_int_t> _missionItemsToUpload;
        private TaskCompletionSource<bool> _missionUploadTcs;
        private int _missionUploadExpectedSeq = -1;
        private DateTime _missionUploadStartTime;

        private List<MAVLink.mavlink_mission_item_int_t> _downloadedMissionItems;
        private TaskCompletionSource<List<MAVLink.mavlink_mission_item_int_t>> _missionDownloadTcs;
        private int _missionDownloadExpectedCount = 0;
        private bool _isDownloading = false;

        public void SetActiveMission(List<WaypointItem> mission)
        {
            _activeMission = mission != null ? new List<WaypointItem>(mission) : null;
            System.Diagnostics.Debug.WriteLine($"✅ Активная миссия установлена: {_activeMission?.Count ?? 0} точек");
        }

        public bool IsConnected { get; private set; }
        public Telemetry CurrentTelemetry { get; private set; }
        public DroneStatus DroneStatus { get; private set; }

        public double? HomeLat { get; private set; }
        public double? HomeLon { get; private set; }
        public double? HomeAlt { get; private set; }
        public bool HasHomePosition => HomeLat.HasValue && HomeLon.HasValue;

        public event EventHandler<Telemetry> TelemetryUpdated;
        public event EventHandler<string> ConnectionStatusChanged;
        public event EventHandler<string> ErrorOccurred;
        public event EventHandler<bool> ConnectionStatusChanged_Bool;
        public event EventHandler TelemetryReceived;
        public event EventHandler<string> MessageReceived;
        public event Action<string> OnStatusTextReceived;
        public event EventHandler<int> MissionProgressUpdated;

        public event Action<byte, byte, byte[], float, float, float> OnMagCalProgress;

        public event Action<byte, byte, float, float, float, float> OnMagCalReport;

        public int CurrentMissionSeq { get; private set; } = 0;

        public long TotalBytesReceived { get; private set; }
        public long TotalPacketsReceived { get; private set; }
        public long TotalPacketsSent { get; private set; }
        public long PacketErrors { get; private set; }

        private const byte GCS_SYSTEM_ID = 255;
        private const byte GCS_COMPONENT_ID = 190;
        private const int HEARTBEAT_INTERVAL_MS = 1000;
        private const int TELEMETRY_REQUEST_INTERVAL_MS = 5000;

        public MAVLinkService()
        {
            CurrentTelemetry = new Telemetry();
            DroneStatus = new DroneStatus();
            _parser = new MavlinkParse();
        }

        public bool ConnectUDP(string localIp, int localPort)
        {
            // ... реализация (33 строк) ...
            throw new NotImplementedException();
        }

        public bool ConnectUDP(string localIp, int localPort, string hostIp, int hostPort)
        {
            // ... реализация (34 строк) ...
            throw new NotImplementedException();
        }

        private void StartConnectionTimeoutCheck()
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private async Task ReadLoopUDP(CancellationToken ct)
        {
            // ... реализация (53 строк) ...
            throw new NotImplementedException();
        }

        public bool Connect(string portName, int baudRate)
        {
            // ... реализация (67 строк) ...
            throw new NotImplementedException();
        }

        public void Disconnect()
        {
            // ... реализация (29 строк) ...
            throw new NotImplementedException();
        }

        public TimeSpan GetConnectionTime()
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        public static string[] GetAvailablePorts()
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void StartHeartbeatTimer()
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private void CheckConnectionTimeout()
        {
            // ... реализация (12 строк) ...
            throw new NotImplementedException();
        }

        private void StartTelemetryRequestTimer()
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private byte _vehicleMavType = (byte)MAVLink.MAV_TYPE.QUADROTOR;

        private void SendHeartbeat()
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        public void SetVehicleType(byte mavType)
        {
            _vehicleMavType = mavType;
        }

        private void RequestDataStreams()
        {
            // ... реализация (21 строк) ...
            throw new NotImplementedException();
        }

        private void RequestDataStream(MAVLink.MAV_DATA_STREAM streamId, ushort rate, bool enable)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private async Task ReadLoop(CancellationToken token)
        {
            // ... реализация (100 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessHomePosition(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMessage(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (103 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessHeartbeat(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (23 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessAttitude(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessGlobalPosition(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessGpsRaw(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (11 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessVfrHud(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessSysStatus(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMissionCurrent(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMagCalProgress(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMagCalReport(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessStatusText(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessCommandAck(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessServoOutput(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        private int PwmToPercent(ushort pwm)
        {
            if (pwm <= 1000) return 0;
            if (pwm >= 2000) return 100;
            return (pwm - 1000) / 10;
        }

        private void ProcessRcChannels(MAVLink.MAVLinkMessage msg)
        {

        }

        private void ProcessRawImu(MAVLink.MAVLinkMessage msg)
        {

        }

        private void ProcessScaledPressure(MAVLink.MAVLinkMessage msg)
        {

        }

        private void ProcessBatteryStatus(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        private string GetFlightModeName(uint customMode)
        {
            // ... реализация (66 строк) ...
            throw new NotImplementedException();
        }

        public void SendArm()
        {
            SetArm(true);
        }

        public void SendDisarm()
        {
            SetArm(false);
        }

        public void SetArm(bool arm, bool force = false)
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }

        public void ForceArm()
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }

        public void Takeoff(double altitude)
        {
            // ... реализация (31 строк) ...
            throw new NotImplementedException();
        }

        public void Land()
        {
            // ... реализация (37 строк) ...
            throw new NotImplementedException();
        }

        public void ReturnToLaunch()
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        public void SetMode(uint mode)
        {
            // ... реализация (17 строк) ...
            throw new NotImplementedException();
        }

        public void GoTo(double latitude, double longitude, double altitude)
        {
            // ... реализация (29 строк) ...
            throw new NotImplementedException();
        }

        public void Stop()
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        public void SetFlightMode(string modeName)
        {
            // ... реализация (69 строк) ...
            throw new NotImplementedException();
        }

        public void SendCommandLong(ushort command,
            float param1 = 0, float param2 = 0, float param3 = 0,
            float param4 = 0, float param5 = 0, float param6 = 0, float param7 = 0)
        {
            // ... реализация (28 строк) ...
            throw new NotImplementedException();
        }

        public void SendPreflightCalibration(bool gyro = false, bool barometer = false,
                                     bool accelerometer = false, bool compassMot = false,
                                     bool radioTrim = false)
        {
            // ... реализация (36 строк) ...
            throw new NotImplementedException();
        }

        public void SendTakeoff(double altitude)
        {
            Takeoff(altitude);
        }

        public void SendLand()
        {
            Land();
        }

        public void SendRTL()
        {
            ReturnToLaunch();
        }

        public void SetParameter(string paramName, float value)
        {
            // ... реализация (23 строк) ...
            throw new NotImplementedException();
        }

        public void SetVTOLAutoTransition(bool autoTransition)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        public void SendSetHome(bool useCurrentLocation, double lat = 0, double lon = 0, double alt = 0)
        {
            // ... реализация (25 строк) ...
            throw new NotImplementedException();
        }

        public void SavePlannedMission(List<WaypointItem> waypoints)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        public List<WaypointItem> GetPlannedMission()
        {
            return _plannedMission;
        }

        public async Task<bool> UploadPlannedMission()
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        public async Task<bool> UploadMission(List<WaypointItem> waypoints)
        {
            // ... реализация (84 строк) ...
            throw new NotImplementedException();
        }

        private async Task<bool> FallbackSequentialUpload()
        {
            // ... реализация (23 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMissionRequestInt(MAVLink.MAVLinkMessage msg)
        {
            var req = (MAVLink.mavlink_mission_request_int_t)msg.data;
            SendRequestedMissionItem(req.seq);
        }

        private void ProcessMissionRequest(MAVLink.MAVLinkMessage msg)
        {
            var req = (MAVLink.mavlink_mission_request_t)msg.data;
            SendRequestedMissionItem(req.seq);
        }

        private void SendRequestedMissionItem(ushort seq)
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMissionAck(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        public async Task<List<MAVLink.mavlink_mission_item_int_t>> DownloadMission(int timeoutMs = 10000)
        {
            if (!IsConnected) return null;

            try
            {
                _isDownloading = true;
                _downloadedMissionItems = new List<MAVLink.mavlink_mission_item_int_t>();
                _missionDownloadTcs = new TaskCompletionSource<List<MAVLink.mavlink_mission_item_int_t>>();
                _missionDownloadExpectedCount = 0;

                var request = new MAVLink.mavlink_mission_request_list_t
                {
                    target_system = (byte)DroneStatus.SystemId,
                    target_component = (byte)DroneStatus.ComponentId,
                    mission_type = 0
                };
                SendMessage(request, MAVLink.MAVLINK_MSG_ID.MISSION_REQUEST_LIST);
                System.Diagnostics.Debug.WriteLine("[DOWNLOAD] Отправлен MISSION_REQUEST_LIST");

                var timeoutTask = Task.Delay(timeoutMs);
                var completedTask = await Task.WhenAny(_missionDownloadTcs.Task, timeoutTask);

                _isDownloading = false;

                if (completedTask == timeoutTask)
                {
                    System.Diagnostics.Debug.WriteLine("[DOWNLOAD] ❌ Таймаут");
                    _missionDownloadTcs.TrySetResult(null);
                    return null;
                }

                return await _missionDownloadTcs.Task;
            }
            catch (Exception ex)
            {
                _isDownloading = false;
                System.Diagnostics.Debug.WriteLine($"[DOWNLOAD] Ошибка: {ex.Message}");
                return null;
            }
        }

        private void ProcessMissionCount(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (18 строк) ...
            throw new NotImplementedException();
        }

        private void ProcessMissionItemInt(MAVLink.MAVLinkMessage msg)
        {
            // ... реализация (24 строк) ...
            throw new NotImplementedException();
        }

        private void RequestMissionItem(ushort seq)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private void SendMissionAck(MAVLink.MAV_MISSION_RESULT result)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        public async Task<bool> ModifyWaypointInFlight(WaypointItem wp, int missionSeq)
        {
            // ... реализация (44 строк) ...
            throw new NotImplementedException();
        }

        public async Task<bool> ReuploadMissionInFlight(List<WaypointItem> waypoints, int resumeFromSeq = -1)
        {
            // ... реализация (13 строк) ...
            throw new NotImplementedException();
        }

        private MAVLink.mavlink_mission_item_int_t CreateHomeWaypoint(WaypointItem firstWaypoint)
        {
            return new MAVLink.mavlink_mission_item_int_t
            {
                target_system = (byte)DroneStatus.SystemId,
                target_component = (byte)DroneStatus.ComponentId,
                seq = 0,
                frame = (byte)MAVLink.MAV_FRAME.GLOBAL,  // HOME = absolute altitude (MSL)
                command = (ushort)MAVLink.MAV_CMD.WAYPOINT,
                current = 0, // HOME seq=0 current should be 0
                autocontinue = 1,
                param1 = 0,
                param2 = 0,
                param3 = 0,
                param4 = 0,
                x = (int)(firstWaypoint.Latitude * 1e7),
                y = (int)(firstWaypoint.Longitude * 1e7),
                z = (float)firstWaypoint.Altitude,
                mission_type = 0
            };
        }

        private MAVLink.mavlink_mission_item_int_t ConvertToMissionItem(WaypointItem wp, int sequence)
        {
            ushort mavCmd;

            bool isNavCommand = wp.CommandType == "WAYPOINT" || wp.CommandType == "SPLINE_WP";

            if (!wp.AutoNext && isNavCommand)
            {
                mavCmd = (ushort)MAVLink.MAV_CMD.LOITER_UNLIM;
            }

            else if (wp.LoiterTurns > 0 && isNavCommand)
            {
                mavCmd = 18;
            }

            else
            {
                mavCmd = ConvertCommandTypeToMAVCmd(wp.CommandType);
            }

            float param1 = 0;
            float param2 = 0;
            float param3 = 0;
            float param4 = 0;

            float signedRadius = wp.Clockwise ? (float)Math.Abs(wp.Radius) : -(float)Math.Abs(wp.Radius);

            if (mavCmd == (ushort)MAVLink.MAV_CMD.LOITER_UNLIM)
            {
                param3 = signedRadius;
            }

            else if (mavCmd == 18)
            {
                param1 = (float)wp.LoiterTurns;
                param3 = signedRadius;
            }
            else
            {

                switch (wp.CommandType)
                {
                    case "VTOL_TRANSITION_FW":
                        param1 = 4;
                        break;
                    case "VTOL_TRANSITION_MC":
                        param1 = 3;
                        break;
                    case "DELAY":
                        param1 = (float)wp.Delay;
                        break;
                    case "LOITER_TIME":
                        param1 = (float)wp.Delay;
                        param3 = signedRadius;
                        break;
                    case "LOITER_TURNS":
                        param1 = (float)wp.LoiterTurns;
                        param3 = signedRadius;
                        break;
                    case "LOITER_UNLIM":
                        param3 = signedRadius;
                        break;
                    case "CHANGE_SPEED":
                        param1 = 1;
                        param2 = (float)wp.Delay;
                        param3 = -1;
                        break;
                    case "WAYPOINT":
                        param1 = (float)wp.Delay;
                        param2 = 0;
                        break;
                    case "SPLINE_WP":
                        param1 = (float)wp.Delay;
                        break;
                    case "VTOL_TAKEOFF":
                    case "VTOL_LAND":

                        break;
                    default:
                        param1 = (float)wp.Delay;
                        break;
                }
            }

            return new MAVLink.mavlink_mission_item_int_t
            {
                target_system = (byte)DroneStatus.SystemId,
                target_component = (byte)DroneStatus.ComponentId,
                seq = (ushort)sequence,
                frame = (byte)MAVLink.MAV_FRAME.GLOBAL_RELATIVE_ALT,
                command = mavCmd,
                current = 0,
                autocontinue = (byte)(wp.AutoNext ? 1 : 0),
                param1 = param1,
                param2 = param2,
                param3 = param3,
                param4 = param4,
                x = (int)(wp.Latitude * 1e7),
                y = (int)(wp.Longitude * 1e7),
                z = (float)wp.Altitude,
                mission_type = 0
            };
        }

        private ushort ConvertCommandTypeToMAVCmd(string commandType)
        {
            // ... реализация (20 строк) ...
            throw new NotImplementedException();
        }

        private void SendMissionItem(MAVLink.mavlink_mission_item_int_t item)
        {
            SendMessage(item, MAVLink.MAVLINK_MSG_ID.MISSION_ITEM_INT);
        }

        public void StartMission()
        {
            // ... реализация (34 строк) ...
            throw new NotImplementedException();
        }

        public void PauseMission()
        {
            // ... реализация (15 строк) ...
            throw new NotImplementedException();
        }

        public async Task<bool> UploadVtolMission(
            WaypointItem home,
            WaypointItem startCircle,
            List<WaypointItem> waypoints,
            WaypointItem landingCircle,
            double takeoffAltitude,
            double landAltitude)
        {
            // ... реализация (130 строк) ...
            throw new NotImplementedException();
        }

        private MAVLink.mavlink_mission_item_int_t CreateLoiterItem(WaypointItem wp, int sequence)
        {
            ushort command;
            float param1 = 0;

            if (!wp.AutoNext)
            {
                command = 17;
                param1 = 0;
            }
            else if (wp.LoiterTurns > 0)
            {
                command = 18;
                param1 = wp.LoiterTurns;
            }
            else
            {
                command = 16;
                param1 = (float)wp.Delay;
            }

            float signedRadius = wp.Clockwise ? (float)Math.Abs(wp.Radius) : -(float)Math.Abs(wp.Radius);

            return new MAVLink.mavlink_mission_item_int_t
            {
                target_system = (byte)DroneStatus.SystemId,
                target_component = (byte)DroneStatus.ComponentId,
                seq = (ushort)sequence,
                frame = (byte)MAVLink.MAV_FRAME.GLOBAL_RELATIVE_ALT,
                command = command,
                current = 0,
                autocontinue = (byte)(wp.AutoNext ? 1 : 0),
                param1 = param1,
                param2 = 0,
                param3 = signedRadius,
                param4 = 0,
                x = (int)(wp.Latitude * 1e7),
                y = (int)(wp.Longitude * 1e7),
                z = (float)wp.Altitude,
                mission_type = 0
            };
        }

        public void SetCurrentWaypoint(ushort seq)
        {
            // ... реализация (13 строк) ...
            throw new NotImplementedException();
        }

        public void ClearMission()
        {
            // ... реализация (13 строк) ...
            throw new NotImplementedException();
        }

        private void SendMessage(object message, MAVLink.MAVLINK_MSG_ID messageId)
        {
            // ... реализация (31 строк) ...
            throw new NotImplementedException();
        }

        public string GetStatistics()
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        public void ResetStatistics()
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

    }
}