using System;
using System.Diagnostics;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleDroneGCS.Services
{
    
    public class Z30TCameraService : IDisposable
    {

        private TcpClient _tcpClient;
        private NetworkStream _stream;
        private CancellationTokenSource _cts;

        private bool _isConnected;
        private bool _isRecording;
        private bool _isTracking;
        private bool _isIRMode;
        private bool _isLaserOn;
        private bool _isLightOn;
        private bool _isOSDOn = true;
        private int _currentPalette;

        public bool IsConnected => _isConnected;
        public bool IsRecording => _isRecording;
        public bool IsTracking => _isTracking;
        public bool IsIRMode => _isIRMode;
        public bool IsLaserOn => _isLaserOn;
        public bool IsLightOn => _isLightOn;
        public bool IsOSDOn => _isOSDOn;
        public int CurrentPalette => _currentPalette;

        public string IpAddress { get; set; } = "192.168.144.68";
        public int Port { get; set; } = 2000;
        public string RtspUrl => $"rtsp://{IpAddress}:554/chn0";

        public event Action<string> StatusChanged;
        public event EventHandler<string> ErrorOccurred;
        public event EventHandler<GimbalAngles> AnglesReceived;
        public event EventHandler<double> DistanceReceived;

        private static (byte lo, byte hi) CalcCRC(byte[] data, int length)
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private static byte[] BuildPacket(byte cmd, byte dataLen, params byte[] data)
        {
            // ... реализация (16 строк) ...
            throw new NotImplementedException();
        }

        public async Task<bool> ConnectAsync()
        {
            // ... реализация (34 строк) ...
            throw new NotImplementedException();
        }

        public void Disconnect()
        {
            // ... реализация (9 строк) ...
            throw new NotImplementedException();
        }

        private async Task ReceiveLoop(CancellationToken token)
        {
            // ... реализация (32 строк) ...
            throw new NotImplementedException();
        }

        private void ParseResponse(byte[] data, int length)
        {
            // ... реализация (45 строк) ...
            throw new NotImplementedException();
        }

        private bool Send(byte[] packet)
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        public void SetGimbalSpeed(int yaw, int pitch)
        {
            // ... реализация (17 строк) ...
            throw new NotImplementedException();
        }

        public void StopGimbal()
        {
            Send(BuildPacket(0x07, 0x02, 0x00, 0x00)); 
            Send(BuildPacket(0x08, 0x02, 0x00, 0x00)); 
        }

        public void ReturnToCenter()
        {
            Send(BuildPacket(0x0F, 0x01, 0x00));
            StatusChanged?.Invoke("Подвес → центр");
        }

        public void LookDown()
        {
            Send(BuildPacket(0x08, 0x02, 0x7C, 0xFC));
            StatusChanged?.Invoke("Подвес → вниз");
        }

        public void ZoomIn()
        {
            Send(BuildPacket(0x31, 0x01, 0x01));
        }

        public void ZoomOut()
        {
            Send(BuildPacket(0x31, 0x01, 0x00));
        }

        public void ZoomStop()
        {
            Send(BuildPacket(0x31, 0x01, 0x02));
        }

        public void AutoFocus()
        {
            Send(BuildPacket(0x14, 0x01, 0x01));
            StatusChanged?.Invoke("Автофокус");
        }

        public void SetVideoEO()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void SetVideoIR()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void SetVideoEO_IR_PIP()
        {
            Send(BuildPacket(0x20, 0x01, 0x02));
            StatusChanged?.Invoke("Режим: EO+IR PIP");
        }

        public void SetVideoIR_EO_PIP()
        {
            Send(BuildPacket(0x20, 0x01, 0x03));
            StatusChanged?.Invoke("Режим: IR+EO PIP");
        }

        public void SetVideoFusion()
        {
            Send(BuildPacket(0x20, 0x01, 0x04));
            StatusChanged?.Invoke("Режим: Фьюжн");
        }

        public static readonly string[] PaletteNames =
        {
            "White Hot", "Lava", "Iron Red", "Hot Iron", "Medical",
            "Arctic", "Rainbow 1", "Rainbow 2", "Red Trace", "Black Hot"
        };

        public void SetIRPalette(int index)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        public void SetIRPaletteWhiteHot() => SetIRPalette(0);
        public void SetIRPaletteLava() => SetIRPalette(1);
        public void SetIRPaletteIronRed() => SetIRPalette(2);
        public void SetIRPaletteHotIron() => SetIRPalette(3);
        public void SetIRPaletteMedical() => SetIRPalette(4);
        public void SetIRPaletteArctic() => SetIRPalette(5);
        public void SetIRPaletteRainbow1() => SetIRPalette(6);
        public void SetIRPaletteRainbow2() => SetIRPalette(7);
        public void SetIRPaletteRedTrace() => SetIRPalette(8);
        public void SetIRPaletteBlackHot() => SetIRPalette(9);
        public void NextPalette() => SetIRPalette((_currentPalette + 1) % PaletteNames.Length);

        public void TakePhoto()
        {
            Send(BuildPacket(0x1C, 0x00));
            StatusChanged?.Invoke("📸 Снимок");
        }

        public void ToggleRecording()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void EnableSearchMode()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void StopTracking()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void ToggleAIDetection()
        {
            if (_isTracking) StopTracking();
            else EnableSearchMode();
        }

        public void SetTrackingPoint(float normX, float normY)
        {
            // ... реализация (14 строк) ...
            throw new NotImplementedException();
        }

        public void ToggleLaser()
        {
            // ... реализация (6 строк) ...
            throw new NotImplementedException();
        }

        public void LaserOn()
        {
            if (!_isLaserOn) ToggleLaser();
        }

        public void LaserOff()
        {
            if (_isLaserOn) ToggleLaser();
        }

        public void LRFMeasureSingle() => ToggleLaser();
        public void LRFMeasureContinuous() => LaserOn();
        public void LRFStop() => LaserOff();

        public void SetFillLight(bool on)
        {
            // ... реализация (10 строк) ...
            throw new NotImplementedException();
        }

        public void ToggleFillLight() => SetFillLight(!_isLightOn);

        private int _tempGear = 0;
        public int TempGear => _tempGear;
        public bool IsTempMeasuring => _tempGear > 0;

        public void SetTempGear(int gear)
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        public void NextTempGear()
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

        public void MeasureTemperature() => NextTempGear();

        public void ToggleOSD()
        {
            // ... реализация (7 строк) ...
            throw new NotImplementedException();
        }

        private static int Clamp(int val, int min, int max)
        {
            if (val < min) return min;
            if (val > max) return max;
            return val;
        }

        public void Dispose()
        {
            Disconnect();
        }

    }
}
