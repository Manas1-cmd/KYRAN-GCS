using System;
using System.Collections.Generic;
using SimpleDroneGCS.Models;

namespace SimpleDroneGCS.Services
{
    public class VehicleManager
    {
        private static VehicleManager _instance;
        public static VehicleManager Instance => _instance ??= new VehicleManager();

        public VehicleType CurrentVehicleType { get; private set; }
        public VehicleProfile CurrentProfile { get; private set; }

        private readonly Dictionary<VehicleType, VehicleProfile> _profiles;

        private VehicleManager()
        {
            _profiles = InitializeProfiles();
            CurrentVehicleType = VehicleType.Copter; 
            CurrentProfile = _profiles[CurrentVehicleType];
        }

        public void SetVehicleType(VehicleType type)
        {
            // ... реализация (5 строк) ...
            throw new NotImplementedException();
        }

        public event EventHandler<VehicleProfile> VehicleTypeChanged;

        private Dictionary<VehicleType, VehicleProfile> InitializeProfiles()
        {
            // ... реализация (199 строк) ...
            throw new NotImplementedException();
        }

        public string[] GetFlightModesForCurrentVehicle()
        {
            return CurrentProfile.SupportedFlightModes;
        }

        public TelemetryConfiguration GetTelemetryConfig()
        {
            return CurrentProfile.TelemetryConfig;
        }

        public string GetVehicleIconPath()
        {
            return CurrentProfile.IconPath ?? GetDefaultIconPath();
        }

        private string GetDefaultIconPath()
        {
            // ... реализация (8 строк) ...
            throw new NotImplementedException();
        }

    }
    
    public static class VehicleTypeExtensions
    {
        public static List<string> GetFlightModes(this VehicleType vehicleType)
        {
            // ... реализация (30 строк) ...
            throw new NotImplementedException();
        }

        public static List<string> GetCalibrations(this VehicleType vehicleType)
        {
            // ... реализация (24 строк) ...
            throw new NotImplementedException();
        }
    }
}
